#include <Wire.h>
#include <math.h>

/* 
NOTE : CE CODE PERMET DE COLLECTER LES DONNEES D'UN ADXL355Z EN I2C. 
LE TRANSFERT DES DONNEES VIA BLE N'EST PAS PRIS EN CHARGE
*/

// Adresse I2C de l'ADXL355 (MISO/ASEL relié au GND)
const int ADXL355_ADDR = 0x1D;

// Registres
const int REG_POWER_CTL = 0x2D;
const int REG_XDATA3 = 0x08;
const int REG_RANGE = 0x2C;

// Facteur d'échelle pour la plage par défaut (+/- 2g) : 256000 LSB/g
const float SCALE_FACTOR = 256000;

void setup() {
  Serial.begin(115200);
  Wire.begin();

  // Attendre que le port série soit prêt
  while (!Serial) { delay(10); }
  Serial.println("Initialisation de l'ADXL355...");
  
  Wire.beginTransmission(ADXL355_ADDR);
  Wire.write(REG_RANGE);
  Wire.write(0x01); // 0x01 pour 2g, 0x02 pour 4g, 0x03 pour 8g
  if (Wire.endTransmission() != 0) {
    Serial.print("Erreur de communication I2C.");
    while(1); // Bloque le programme si le capteur n'est pas détecté
  }

  // Il faut écrire 0x00 dans POWER_CTL pour passer en mode de mesure.
  Wire.beginTransmission(ADXL355_ADDR);
  Wire.write(REG_POWER_CTL);
  Wire.write(0x00);
  if (Wire.endTransmission() != 0) {
    Serial.println("Erreur de communication I2C.");
    while(1); // Bloque le programme si le capteur n'est pas détecté
  }
   
  Serial.println("ADXL355 prêt en mode mesure.");
}

void loop() {
  // Lecture de 9 octets à partir du registre XDATA3 (0x08)
  // L'adresse s'auto-incrémente pour lire X, Y et Z d'un coup.
  Wire.beginTransmission(ADXL355_ADDR);
  Wire.write(REG_XDATA3);
  Wire.endTransmission(false);
  Wire.requestFrom(ADXL355_ADDR, 9);

  if (Wire.available() == 9) {
    // Lecture des octets
    uint32_t x3 = Wire.read();
    uint32_t x2 = Wire.read();
    uint32_t x1 = Wire.read();
    
    uint32_t y3 = Wire.read();
    uint32_t y2 = Wire.read();
    uint32_t y1 = Wire.read();
    
    uint32_t z3 = Wire.read();
    uint32_t z2 = Wire.read();
    uint32_t z1 = Wire.read();

    // Recomposition des données 20 bits (alignées à gauche dans 3 octets)
    int32_t x_raw = (x3 << 12) | (x2 << 4) | (x1 >> 4);
    int32_t y_raw = (y3 << 12) | (y2 << 4) | (y1 >> 4);
    int32_t z_raw = (z3 << 12) | (z2 << 4) | (z1 >> 4);

    // Extension de signe pour les nombres négatifs (complément à deux sur 20 bits)
    if (x_raw & 0x00080000) x_raw |= 0xFFF00000;
    if (y_raw & 0x00080000) y_raw |= 0xFFF00000;
    if (z_raw & 0x00080000) z_raw |= 0xFFF00000;

    // Conversion en g (gravité)
    float ax = (float)x_raw / SCALE_FACTOR;
    float ay = (float)y_raw / SCALE_FACTOR;
    float az = (float)z_raw / SCALE_FACTOR;

    // Calcul de l'inclinaison (Roulis et Tangage) en degrés
    // Note : az doit être différent de 0 pour éviter une division par zéro dans de rares cas.
    float roll = atan2(ay, az) * 180.0 / PI;
    float pitch = atan2(-ax, sqrt(ay * ay + az * az)) * 180.0 / PI;

    // Affichage des données
    Serial.print("Accélérations [g] -> X: ");
    Serial.print(ax, 4);
    Serial.print(" | Y: ");
    Serial.print(ay, 4);
    Serial.print(" | Z: ");
    Serial.print(az, 4);
    
    Serial.print("  ||  Inclinaison [deg] -> Pitch: ");
    Serial.print(pitch, 2);
    Serial.print(" | Roll: ");
    Serial.println(roll, 2);
  }

  delay(100); // 10 lectures par seconde
}